# Research Notes and Product Architecture Decisions

This document records the official documentation sources, comparable project analysis, and architectural decisions behind **Works, Actually** (`v0.1.0`).

## 1. Official Standards and Documentation Consulted

1. **Claude Code Skills Documentation** ([Extend Claude with skills](https://code.claude.com/docs/en/skills) and [Explore the .claude directory](https://code.claude.com/docs/en/claude-directory)):
   - Verified directory locations:
     - Personal scope: `~/.claude/skills/<skill-name>/SKILL.md` (`%USERPROFILE%\.claude\skills\<skill-name>\SKILL.md` on Windows), available across all local projects.
     - Project scope: `.claude/skills/<skill-name>/SKILL.md`, committed to the repository and shared with the team.
   - Verified frontmatter fields: `name`, `description`, `argument-hint`, `disable-model-invocation`, `user-invocable`, `allowed-tools`, `license`, `compatibility`, `metadata`.
   - Verified context lifecycle: Only `name` and `description` are loaded into the startup skill listing; the `SKILL.md` body is loaded when the skill is invoked, and files in `references/` load on demand. Keeping `SKILL.md` well under 500 lines preserves context budget.
   - Verified built-in commands for checking installed skills: `/skills` and `/reload-skills`.
2. **Agent Skills Open Specification** ([Agent Skills Specification](https://agentskills.io/specification)):
   - Verified required frontmatter (`name` max 64 chars, lowercase alphanumeric + hyphens; `description` max 1024 chars, capability + trigger conditions) and optional subfolders (`references/`, `scripts/`, `assets/`).
3. **Skills CLI Installation Conventions** ([vercel-labs/skills CLI Reference](https://github.com/vercel-labs/skills/blob/main/docs/commands.md)):
   - Verified exact syntax for `npx skills add <owner/repo> --skill <name> --agent claude-code` and `--global`.
   - Placed canonical skill files at `skills/works-actually/SKILL.md` (discovered automatically by `npx skills add`) and mirrored them at `.claude/skills/works-actually/SKILL.md` so users who clone or work inside this repository get the skill immediately.

## 2. Comparable Projects Reviewed & Differentiation

| Project / Tool | What It Does | License | How `Works, Actually` Differentiates |
| :--- | :--- | :--- | :--- |
| **[obra/superpowers](https://github.com/obra/superpowers)** (`verification-before-completion`, `systematic-debugging`) | Enforces software engineering workflow discipline for developers (for example, requiring test/build command execution before claiming a task is complete). | MIT | Superpowers is an engineering methodology for developers *during* coding. `Works, Actually` is built for **vibe coders and nontechnical founders** to audit whether a user-facing web feature works end-to-end, translate technical evidence into plain English, and hand off a structured Fix Brief. |
| **Claude Code Bundled `/verify` & `/run`** ([Claude Code Docs](https://code.claude.com/docs/en/skills)) | Launches the application after a code change to verify that a developer's edit works, and records launch recipes in `.claude/skills/verify/SKILL.md`. | Proprietary (Bundled) | `/verify` confirms developer code changes. `Works, Actually` performs a **read-only feature audit** with four explicit evidence labels (`Passed`, `Failed`, `Blocked / not tested`, `Needs human review`), checks backend persistence behind UI toasts, enforces payment/email safety boundaries, and pauses for user approval before editing code. |
| **[Microsoft Playwright MCP](https://claude.com/marketplace/plugins/playwright) & [Playwright Agent CLI Skills](https://playwright.dev/agent-cli/skills)** | Provides browser automation primitives (clicking, typing, screenshots) and test-suite generation for AI agents. | Apache-2.0 / MIT | Playwright tools provide the browser driver. `Works, Actually` provides the **judgment, safety rules, backend verification protocol, fallback hierarchy, and human-friendly reporting format** on top of whatever browser or HTTP tools are available. |
| **[lackeyjb/playwright-skill](https://github.com/lackeyjb/playwright-skill)** | General-purpose Playwright automation skill for Claude Code. | MIT | Focuses on browser scripting mechanics rather than read-only diagnosis, backend state proof, or nontechnical founder handoffs. |

## 3. Key Product & Architecture Decisions

1. **Activation Mode (Both Automatic and Explicit `/works-actually`)**:
   - We left `user-invocable` as default (`true`) and `disable-model-invocation` as default (`false`).
   - **Why**: Vibe coders frequently ask in natural language (*"Does my signup flow actually work?"*), while repeat users prefer typing `/works-actually signup`. Because the checking phase is strictly read-only with respect to application code and stops before external side effects, automatic invocation is safe.
2. **Omitting `allowed-tools` Pre-Approval in Frontmatter**:
   - As documented in [Claude Code security analyses](https://www.alekseialeinikov.com/en/blog/topics/ai/agent-skills-explained-skill-md-vs-mcp), `allowed-tools` in a project skill bypasses normal per-command prompts during the turn it runs. Omitting `allowed-tools` ensures Claude Code continues to respect the user's configured permission mode when starting servers or running checks.
3. **3-Tier Tool Fallback Hierarchy**:
   - Rather than failing when Playwright is not installed—or worse, running `npm install playwright` without permission—the skill uses Tier 1 (Browser automation) when present, degrades to Tier 2 (Local HTTP + DOM + DB state inspection) when browser automation is absent, and falls back to Tier 3 (Static code trace + `Blocked / not tested` runtime labels) when the server cannot start.
4. **Repository Name Availability (`aiwithjash/works-actually`)**:
   - Web search verification confirmed no existing repository or name collision at `https://github.com/aiwithjash/works-actually`.
   - If the name is taken at the moment of creation on GitHub, recommended fallback names are `works-actually-skill` or `claude-works-actually`.
