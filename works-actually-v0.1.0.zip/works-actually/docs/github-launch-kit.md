# GitHub Launch Kit & Repository Metadata

Use the copy below when publishing `https://github.com/aiwithjash/works-actually` and configuring the repository settings on GitHub.

> **Status Note**: These settings and release notes have been prepared locally and have **not** yet been applied on GitHub.

## 1. Repository Settings Metadata

- **Repository Name**: `works-actually` (Fallback alternatives if needed: `works-actually-skill`, `claude-works-actually`)
- **Repository Title**: Works, Actually - Does it actually work?
- **Short GitHub Description (156 characters, fits GitHub's 350-char limit)**:
  `Claude Code skill that checks if your AI-built website or web app feature actually works, verifies backend evidence, and hands off a plain-English fix brief.`
- **Website URL (Optional)**: `https://github.com/aiwithjash/works-actually#readme`
- **Social Preview Image**: Upload `assets/social-preview.png` (`1280x640`, 2:1 ratio) under **Settings -> General -> Social preview**.
- **Social Preview Alt Text**:
  `Works, Actually - Open-source Claude Code skill for user-journey QA on AI-built web apps. Shows Passed, Failed, Blocked/Safe, and Fix Handoff cards.`

## 2. Suggested GitHub Topics (12 topics)

```text
claude-code
claude-code-skill
agent-skills
vibe-coding
qa-testing
user-journey-testing
web-testing
ai-coding-assistant
playwright
e2e-testing
indie-hackers
developer-tools
```

## 3. First Release Metadata (`v0.1.0`)

- **Tag**: `v0.1.0`
- **Release Title**: `v0.1.0 - Initial Release: Does it actually work?`
- **Release Notes**:

```markdown
## Works, Actually v0.1.0

**Does it actually work?**

`Works, Actually` is a problem-finding and fix-handoff skill for **Claude Code** (built on the open [Agent Skills](https://agentskills.io/specification) format). It helps vibe coders, nontechnical founders, and builders verify whether a website or web app feature genuinely works from a real user's perspective—beyond a pretty UI or a fake success toast.

### Highlights
- **Read-Only Audit First**: Investigates one user-specified feature at a time without silently editing your application code.
- **Evidence Over Appearances**: Verifies both UI behavior and backend persistence (database rows, session state, uploaded files) and labels every check honestly (`Passed`, `Failed`, `Blocked / not tested`, `Needs human review`).
- **Practical Safety Boundaries**: Defaults to local/test environments and stops before charging live payments, sending real emails, or modifying production data.
- **Plain-English Report + Agent Fix Brief**: Translates findings into clear language for founders while giving Claude Code exact file locations, fix instructions, and re-verification steps.
- **Clean Handoff Choice**: Always asks `"I found these issues. Would you like me to fix them?"` before modifying application code.

### Quick Install
```bash
git clone https://github.com/aiwithjash/works-actually.git /tmp/works-actually
mkdir -p ~/.claude/skills
cp -R /tmp/works-actually/skills/works-actually ~/.claude/skills/works-actually
rm -rf /tmp/works-actually
```
```

## 4. Launch Post Copy (X / LinkedIn / Reddit / Product Hunt)

### Short X / Social Launch Post
```text
Ever built a feature with AI where the button shows a green "Success!" toast... but nothing actually saved to the database?

I just open-sourced "Works, Actually" — a Claude Code skill made for vibe coders & founders.

Ask "/works-actually signup flow" and it:
1. Tests the real user journey + failure states (read-only)
2. Checks if the backend/DB actually updated
3. Reports what works, what failed, and what's blocked in plain English
4. Writes a fix brief and asks: "I found these issues. Would you like me to fix them?"

No fake passes. No silent code edits. MIT licensed.

Repo: https://github.com/aiwithjash/works-actually
```

### Community Post (r/ClaudeAI / r/ClaudeCode / Hacker News)
```text
Title: Show: Works, Actually - A Claude Code skill that checks if AI-built web features actually work before touching your code

When vibe coding web apps with AI, one of the most common failure modes is the "painted-on feature": a signup form that shows a success banner while POST /api/signup returns 500, or a contact form that clears its inputs without saving anything.

I built Works, Actually (https://github.com/aiwithjash/works-actually) as a lightweight, open-source Claude Code skill to solve this:
- It checks one user-specified feature at a time (signup, cart, checkout, contact form, image upload, booking).
- It is strictly read-only with respect to your app code during the audit.
- It separates Passed, Failed, Blocked / not tested, and Needs human review (missing env vars or live Stripe keys are marked Blocked, never assumed Passed).
- It outputs a plain-English summary alongside a technical Fix Brief, then asks if you want Claude Code to fix the issues and re-verify.

Feedback and PRs welcome!
```
