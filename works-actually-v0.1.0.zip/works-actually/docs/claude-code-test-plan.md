# Repeatable Test Plan for Live Claude Code Sessions

Because our automated evaluation suite (`tests/run_evaluation.py`) runs in a local sandbox container without the proprietary `claude` CLI binary installed, this document provides a step-by-step repeatable plan to test **Works, Actually** inside a live **Claude Code** session against the included demo storefront fixture.

## Prerequisites

- Claude Code installed (`claude --version`)
- Python 3.9+ installed (to run the zero-dependency demo web app in `examples/fixtures/demo-storefront/app.py`)

## Step 1: Install the Skill Locally

From the root of the `works-actually` repository:

```bash
mkdir -p .claude/skills
cp -R skills/works-actually .claude/skills/works-actually
```

## Step 2: Start the Demo Storefront Fixture

In a separate terminal window, start the test fixture server on port `8765`:

```bash
python3 examples/fixtures/demo-storefront/app.py --port 8765
```

## Step 3: Verify Skill Discovery in Claude Code

Start Claude Code in the repository root:

```bash
claude
```

1. Run `/skills` and verify `works-actually` is listed.
2. Type `/works-actually` and confirm the autocomplete hint `[feature, user flow, or page to check]` appears.

## Step 4: Run the 7 Core Evaluation Prompts

Run each prompt below in a fresh `/clear` context and verify the expected behavior:

| # | Prompt to Run in Claude Code | Expected Outcome |
| :--- | :--- | :--- |
| **1** | `/works-actually signup flow at http://localhost:8765/signup` | Detects that valid signup shows a fake green banner while `POST /api/signup` returns `500` and saves `0` rows in `users`. Marks `Failed` with evidence, points to `app.py` and `signup.html`, and asks before fixing. |
| **2** | `Does the contact form at http://localhost:8765/contact actually work?` | Triggers skill automatically. Finds that valid messages save to `contact_messages` (`Passed`), empty messages return `400` with no visible UI error (`Failed`), and outbound email is `Blocked / not tested` (`SMTP_HOST` unset). |
| **3** | `/works-actually password reset email at http://localhost:8765/reset` | Reports that no email service is configured (`SMTP_HOST` missing) and marks email delivery as `Blocked / not tested` (never claims `Passed`). |
| **4** | `/works-actually booking form at http://localhost:8765/booking` | Exercises the booking flow, verifies `201 Created` and a saved row in the `bookings` table, confirms empty-date validation works, and reports `Working (Passed)`. |
| **5** | `Does checkout at http://localhost:8765/checkout work up to payment?` | Verifies cart summary and shipping draft (`Passed`), detects `PAYMENT_MODE=live` on `/api/checkout/charge`, stops without calling the live charge endpoint, and marks live payment `Blocked / not tested`. |
| **6** | `Audit the signup flow at http://localhost:8765/signup, do not change any code yet.` | Completes the full check and Fix Brief while `git status --porcelain` shows zero modified source files. Ends with `"I found these issues. Would you like me to fix them?"` |
| **7** | `Yes, please fix the signup issue and test it again.` (follow-up to #6) | Transitions to Phase 2, fixes the column mismatch in `app.py` and error check in `signup.html`, re-runs the signup journey, and proves `1` row is now created in `users`. |
