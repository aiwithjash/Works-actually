#!/usr/bin/env python3
"""
Simulate installing `works-actually` into isolated Personal (~/.claude/skills)
and Project (.claude/skills) environments using the exact commands documented
in README.md, and verify that all required files load cleanly.
"""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
import yaml

REPO_ROOT = Path(__file__).resolve().parent.parent


def test_personal_and_project_install() -> None:
    with tempfile.TemporaryDirectory(prefix="wa_install_test_") as tmp:
        tmp_path = Path(tmp)
        fake_home = tmp_path / "home"
        fake_project = tmp_path / "my-vibe-app"
        fake_home.mkdir()
        fake_project.mkdir()

        # 1. Test Personal Installation command from local checkout
        personal_cmd = (
            f"mkdir -p '{fake_home}/.claude/skills' && "
            f"cp -R '{REPO_ROOT}/skills/works-actually' '{fake_home}/.claude/skills/works-actually'"
        )
        subprocess.run(personal_cmd, shell=True, check=True)

        personal_skill_md = fake_home / ".claude" / "skills" / "works-actually" / "SKILL.md"
        assert personal_skill_md.exists(), "Personal SKILL.md was not installed"
        assert (fake_home / ".claude" / "skills" / "works-actually" / "references" / "journey-checklists.md").exists()

        # 2. Test Project Installation command from local checkout
        project_cmd = (
            f"mkdir -p '{fake_project}/.claude/skills' && "
            f"cp -R '{REPO_ROOT}/skills/works-actually' '{fake_project}/.claude/skills/works-actually'"
        )
        subprocess.run(project_cmd, shell=True, check=True)

        project_skill_md = fake_project / ".claude" / "skills" / "works-actually" / "SKILL.md"
        assert project_skill_md.exists(), "Project SKILL.md was not installed"

        # 3. Verify YAML frontmatter parses identically in installed target
        raw = project_skill_md.read_text(encoding="utf-8")
        parts = raw.split("---", 2)
        meta = yaml.safe_load(parts[1])
        assert meta["name"] == "works-actually"
        assert "website or web app feature" in meta["description"]

        print("INSTALL SIMULATION PASSED:")
        print(f"  - Personal scope (~/.claude/skills/works-actually/SKILL.md): verified")
        print(f"  - Project scope (.claude/skills/works-actually/SKILL.md): verified")
        print(f"  - Supporting references (journey-checklists, report-templates, tool-fallbacks): verified")


if __name__ == "__main__":
    test_personal_and_project_install()
    sys.exit(0)
