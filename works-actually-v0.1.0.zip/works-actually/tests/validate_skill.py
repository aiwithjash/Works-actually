#!/usr/bin/env python3
"""
Validate SKILL.md frontmatter, structure, markdown links, image references,
and repository hygiene (no secrets or stray temp files).
"""
import re
import sys
from pathlib import Path
import yaml

REPO_ROOT = Path(__file__).resolve().parent.parent
SKILL_DIR = REPO_ROOT / "skills" / "works-actually"
PROJECT_SKILL_DIR = REPO_ROOT / ".claude" / "skills" / "works-actually"
SKILL_MD = SKILL_DIR / "SKILL.md"


def check_frontmatter(skill_md_path: Path) -> list[str]:
    errors = []
    content = skill_md_path.read_text(encoding="utf-8")
    lines = content.splitlines()

    if not lines or lines[0].strip() != "---":
        errors.append("SKILL.md must start with '---' on line 1.")
        return errors

    end_idx = None
    for idx in range(1, len(lines)):
        if lines[idx].strip() == "---":
            end_idx = idx
            break
    if end_idx is None:
        errors.append("SKILL.md YAML frontmatter is missing closing '---'.")
        return errors

    raw_yaml = "\n".join(lines[1:end_idx])
    body = "\n".join(lines[end_idx + 1 :]).strip()

    try:
        meta = yaml.safe_load(raw_yaml)
    except Exception as exc:
        errors.append(f"YAML parse error: {exc}")
        return errors

    name = meta.get("name", "")
    desc = meta.get("description", "")

    if not name or not isinstance(name, str):
        errors.append("Frontmatter 'name' is required and must be a string.")
    else:
        if len(name) > 64:
            errors.append(f"Frontmatter 'name' exceeds 64 chars ({len(name)}).")
        if not re.fullmatch(r"[a-z0-9]+(-[a-z0-9]+)*", name):
            errors.append(f"Frontmatter 'name' ({name}) must be lowercase alphanumeric + single hyphens.")
        if name != skill_md_path.parent.name:
            errors.append(f"Frontmatter 'name' ({name}) does not match folder ({skill_md_path.parent.name}).")

    if not desc or not isinstance(desc, str):
        errors.append("Frontmatter 'description' is required and must be a non-empty string.")
    elif len(desc) > 1024:
        errors.append(f"Frontmatter 'description' exceeds 1024 chars ({len(desc)}).")

    if not body:
        errors.append("SKILL.md body is empty.")
    if len(lines) >= 500:
        errors.append(f"SKILL.md should stay under 500 lines (found {len(lines)} lines).")

    if "—" in content or "–" in content:
        errors.append("SKILL.md contains em-dashes or en-dashes; use standard hyphens or periods.")

    return errors


def check_links_and_assets() -> list[str]:
    errors = []
    md_files = list(REPO_ROOT.rglob("*.md"))
    link_pattern = re.compile(r"\[[^\]]*\]\(([^)]+)\)|src=\"([^\"]+)\"")

    for md_file in md_files:
        text = md_file.read_text(encoding="utf-8")
        # Remove fenced code blocks before checking links so example paths in snippets don't false-trigger
        text_no_code = re.sub(r"```.*?```", "", text, flags=re.DOTALL)
        for match in link_pattern.finditer(text_no_code):
            target = (match.group(1) or match.group(2) or "").strip()
            if not target or target.startswith(("http://", "https://", "mailto:", "#")):
                continue
            target_path = target.split("#")[0]
            if not target_path:
                continue
            resolved = (md_file.parent / target_path).resolve()
            if not resolved.exists():
                errors.append(f"Broken relative reference in {md_file.relative_to(REPO_ROOT)}: {target}")

    required_assets = [
        "assets/banner.svg",
        "assets/banner.png",
        "assets/social-preview.svg",
        "assets/social-preview.png",
        "assets/workflow-diagram.svg",
        "assets/workflow-diagram.png",
    ]
    for rel in required_assets:
        p = REPO_ROOT / rel
        if not p.exists() or p.stat().st_size == 0:
            errors.append(f"Missing or empty asset: {rel}")

    return errors


def check_secret_hygiene() -> list[str]:
    errors = []
    secret_regex = re.compile(
        r"(sk_live_[0-9a-zA-Z]{16,}|ghp_[0-9a-zA-Z]{20,}|AKIA[0-9A-Z]{16}|-----BEGIN (RSA|OPENSSH|EC) PRIVATE KEY-----)"
    )
    for path in REPO_ROOT.rglob("*"):
        if path.is_file() and ".git" not in path.parts and path.suffix in {".md", ".py", ".svg", ".json", ".yml", ".yaml"}:
            text = path.read_text(encoding="utf-8", errors="ignore")
            if secret_regex.search(text):
                errors.append(f"Potential secret pattern detected in {path.relative_to(REPO_ROOT)}")
    return errors


def check_mirror_sync() -> list[str]:
    errors = []
    for src in SKILL_DIR.rglob("*"):
        if src.is_file():
            rel = src.relative_to(SKILL_DIR)
            dst = PROJECT_SKILL_DIR / rel
            if not dst.exists():
                errors.append(f"Mirrored project skill file missing: .claude/skills/works-actually/{rel}")
            elif src.read_bytes() != dst.read_bytes():
                errors.append(f"Mirrored project skill file out of sync: {rel}")
    return errors


def main() -> int:
    all_errors = []
    all_errors.extend(check_frontmatter(SKILL_MD))
    all_errors.extend(check_mirror_sync())
    all_errors.extend(check_links_and_assets())
    all_errors.extend(check_secret_hygiene())

    if all_errors:
        print("VALIDATION FAILED:")
        for e in all_errors:
            print(f"  - {e}")
        return 1

    lines_count = len(SKILL_MD.read_text(encoding="utf-8").splitlines())
    print("VALIDATION PASSED:")
    print(f"  - SKILL.md frontmatter & structure valid ({lines_count} lines, < 500 line budget)")
    print("  - Canonical skills/works-actually and .claude/skills/works-actually in sync")
    print("  - All markdown relative links and 6 visual assets verified")
    print("  - Secret and credential scan clean (0 leaks found)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
