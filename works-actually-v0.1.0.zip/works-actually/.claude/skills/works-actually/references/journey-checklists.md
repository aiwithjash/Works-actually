# User Journey Checklists

Load this reference when planning the 2 to 4 focused checks in Step 4 of `works-actually`. Pick only the checklist matching the feature under test.

## 1. Signup & Registration Flow

- **Happy path**: Enter valid name, email (`wa-test-user@example.com`), and password -> submit -> verify redirect or welcome state.
- **Backend persistence**: Confirm a user record was actually created in the local database or auth store and the password is not stored in cleartext.
- **Duplicate / validation check**: Submit an empty email or an already-registered email -> confirm the form blocks submission and displays a visible, human-readable error message (not an unhandled exception or blank screen).
- **External boundary**: Do not send real welcome or verification emails to external addresses. If email verification is required and no local mail catcher or console link is available, mark email delivery as `Blocked / not tested`.

## 2. Login, Session & Password Reset

- **Happy path**: Log in with valid test credentials -> confirm session cookie/token is set -> reload page or visit a protected route to confirm the session persists.
- **Invalid credentials check**: Enter a wrong password -> confirm `401`/`403` handling displays a clear error message in the UI without crashing or hanging in a loading spinner.
- **Logout check**: Trigger logout -> confirm protected route access is revoked.

## 3. Add to Cart & Shopping Cart State

- **Happy path**: Click "Add to Cart" on a product -> verify cart badge count increments and cart drawer/page lists the item, quantity, and unit price.
- **Persistence check**: Reload the page or navigate to another route -> confirm the cart keeps its items (via `localStorage`, session, or backend cart table) rather than resetting to empty.
- **Quantity / edge check**: Increment quantity or remove an item -> confirm subtotal and total update accurately without `NaN` or negative values.

## 4. Checkout Flow (Up to Payment Boundary)

- **Happy path up to boundary**: With an item in the cart, fill shipping/contact details and proceed to the payment step -> confirm order summary, shipping calculation, and payment session initialization work.
- **Safety boundary (CRITICAL)**:
  - **Never** submit real payment details or trigger a live charge.
  - If Stripe/PayPal/Razorpay is in **live mode** (for example, `pk_live_...`), stop before payment submission and mark live payment execution as `Blocked / not tested (live payment boundary)`.
  - If a verified local mock or sandbox test mode (`pk_test_...`) is configured and authorized, verify checkout session creation without charging real money.
- **Validation check**: Submit checkout with missing required shipping fields -> confirm clear field-level validation messages appear.

## 5. Contact, Lead Capture & Support Forms

- **Happy path**: Fill name, email (`wa-test@example.com`), and message -> submit -> observe network request and UI confirmation.
- **Fake-success detection**: Verify that the form handler actually calls an API endpoint or server action. Many AI-built contact forms only run `setSubmitted(true)` in React without sending or saving anything.
- **Backend effect**: Confirm the message is stored in the database or handed to a configured local mail/webhook transport. If `SMTP_HOST`, `RESEND_API_KEY`, or webhook URLs are missing in the test environment, report the form UI/API behavior and mark external message delivery as `Blocked / not tested`.
- **Error state check**: Simulate or trigger a validation/server error -> verify the UI tells the user their message was not sent instead of showing a false success message.

## 6. File & Image Upload Feature

- **Happy path**: Upload a small valid test image (such as a 1x1 PNG or SVG fixture) -> confirm upload request succeeds, file is stored in the expected local directory or mock bucket, and the preview/returned URL actually loads.
- **Invalid file / size check**: Attempt to upload an unsupported file type or empty payload -> confirm the UI rejects it gracefully with a clear message.
- **Persistence check**: Reload the page -> confirm the uploaded image or attachment reference is saved to the record, not just held in temporary browser `URL.createObjectURL` memory.

## 7. Booking, Appointment & CRUD Creation Flows

- **Happy path**: Select a valid date/time slot and enter test attendee details -> submit -> confirm booking confirmation state.
- **Persistence & conflict check**: Query the local database or reload the schedule view to confirm the appointment was saved with the right timestamp and prevents double-booking if applicable.
- **Validation check**: Submit with a missing date or past date -> confirm clear error feedback.
