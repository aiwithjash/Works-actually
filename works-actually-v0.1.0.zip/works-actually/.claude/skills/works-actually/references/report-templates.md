# Report and Fix Handoff Templates

Load this reference in Step 8 and Step 9 of `works-actually` to format the plain-English report and coding agent fix brief.

## Result Labels Reference

Use only these four status labels:

- **Passed**: Observed runtime and backend behavior directly supports the claim.
- **Failed**: A reproducible bug, silent failure, broken UI state, or server error was observed.
- **Blocked / not tested**: The check could not be completed because a required service, credential, browser tool, or safe sandbox was unavailable.
- **Needs human review**: The check ran, but verifying the final outcome requires human judgment or external account access.

When rolling up multiple sub-checks into a top-level **Result** line, use:

- `Working (Passed)` when all core journey checks passed and no failures occurred.
- `Partially working` when some parts work (such as client validation or UI rendering) but one or more core steps failed or were blocked.
- `Not working (Failed)` when the primary user journey fails to complete its core goal.
- `Blocked / not tested` when the feature could not be exercised at all.

## Template A: Issues Found (Default Audit + Fix Handoff)

```markdown
## Works, Actually Report

**Feature**: [Feature Name, e.g., Signup Flow]
**Result**: [Partially working | Not working (Failed)]
**Environment**: [e.g., Local dev server at http://localhost:3000, SQLite dev.db, Playwright headless Chromium]

### Summary in Plain English
[1-2 sentences explaining what a real user experiences right now without technical jargon.]

### Check Breakdown
- **[Passed]** [Specific check that worked + brief evidence]
- **[Failed]** [Specific check that failed + brief impact]
- **[Blocked / not tested]** [Specific check that could not run + why]

### What Works
- [Plain-English bullet of verified working behavior and the evidence observed]

### Problems Found

#### 1. [Short, clear problem title, e.g., Valid signup returns a server error and creates no account]
- **What happened**: [Plain-English explanation of what the user did, what they saw, and what went wrong behind the scenes.]
- **Evidence**: [Exact HTTP status, response payload, console error, DOM state, or database query count observed.]
- **Likely area**: `[path/to/file:line]` ([State clearly whether this is confirmed by code + error trace or suspected]).
- **Suggested fix**: [Concrete instructions for what the coding agent should change or investigate.]
- **How to verify**: [Exact steps to rerun after applying the fix, including both UI observation and backend state check.]

### Could Not Check (Blocked / Needs Human Review)
- **[Item name]**: [Label: Blocked / not tested OR Needs human review] - [Clear explanation of what was missing, e.g., No email service configured in .env.local, or stopped at live Stripe checkout boundary.]

### Next Step
I found these issues. Would you like me to fix them?
```

## Template B: All Checked Items Passed

```markdown
## Works, Actually Report

**Feature**: [Feature Name]
**Result**: Working (Passed)
**Environment**: [Local URL, tools used, database/storage inspected]

### Summary in Plain English
A real user can complete this feature from start to finish, and the expected result is saved properly.

### What Works
- **[Passed]** [Happy path step + runtime/backend evidence]
- **[Passed]** [Validation/error handling step + evidence]
- **[Passed]** [Persistence check + evidence]

### Could Not Check / Scope Notes
- [Any Blocked / not tested or Needs human review items, plus a reminder that passing this feature check does not certify whole-app security, accessibility, or production readiness.]

### Next Step
No code fixes are needed for the tested flow. Would you like me to check another feature or help set up test credentials for any blocked items?
```

## Template C: Phase 2 Follow-Up (Only After User Authorizes Fixes)

Use this template **only** after the user replies "yes" to the handoff prompt, or when the user's original prompt explicitly requested both checking and fixing.

```markdown
## Phase 2: Authorized Fixes & Re-Verification

### Fixes Applied
1. **[Issue Title]**: Updated `[path/to/file]` to [concise description of code change].

### Re-Test Results
- **[Passed]** [Re-ran the exact user journey from "How to verify": describe new observed UI behavior and backend persistence evidence.]
- **[Passed]** [Regression check on validation/error state.]

### Updated Verdict
**Feature**: [Feature Name]
**Result**: Working (Passed) [or Partially working if external items remain Blocked / not tested]
```
