# Browser and Tool Fallbacks

Load this reference in Step 3 of `works-actually` to choose the highest-fidelity verification method available without installing unapproved packages or breaking the user's project.

## Tool Selection Hierarchy

Always prefer real browser interaction first, then degrade gracefully and report any limitation honestly.

| Tier | Environment Available | What to Run | What You Can Claim as `Passed` | What Must Be Marked `Blocked / not tested` |
| :--- | :--- | :--- | :--- | :--- |
| **Tier 1: Real Browser Automation** | Playwright MCP, Claude Code Chrome integration, existing project Playwright/Cypress, or local headless Chromium/Selenium | Navigate to local URL, fill inputs, click buttons, inspect DOM changes, console logs, network responses, and database/storage state | Full user journey (UI rendering, client JS handlers, network submission, and backend persistence) | External services without sandbox keys (live payments, real emails, production OAuth) |
| **Tier 2: Local Server + HTTP & State Checks** | App runs locally, but no browser automation tool is installed | Inspect frontend form/handler code for client bugs, send realistic HTTP requests (`curl` or Python `urllib`) to form/API endpoints, and inspect local DB/files | Server route behavior, status codes, validation responses, database persistence, and rendered HTML structure | Client-side interactive JavaScript state (such as React modal transitions or browser-only layout issues) |
| **Tier 3: Static Code Trace + Isolated Handler Execution** | App cannot start (missing database, missing `.env`, broken build) | Trace frontend -> API -> DB code path, run isolated handler functions if possible, identify obvious code defects | Nothing at the runtime journey level (do not mark runtime journeys `Passed` from code reading alone) | All live runtime and browser steps must be labeled `Blocked / not tested` with the exact startup blocker noted |

## Practical Rules for Browser and Test Tools

1. **Reuse Before Installing**:
   - Check if `@playwright/test`, `playwright`, `cypress`, or `selenium` is already in `node_modules` or the Python environment, or if a Playwright/Browser MCP tool is active in the Claude Code session.
   - Do **not** run `npm install playwright` or `npx playwright install` during an audit without asking the user first, because downloading browser binaries takes time, disk space, and modifies project files.
2. **Starting the Local App Safely**:
   - Check if the dev server is already running before starting a second process (`lsof -i :3000` or a quick `curl -I http://localhost:3000`).
   - If you start a temporary local server for the check, run it in the background with a short timeout and stop it cleanly when the check finishes so you do not leave orphan processes behind.
3. **Inspecting Local Persistence Without Side Effects**:
   - For SQLite / local JSON / file stores: run read-only queries (`SELECT count(*), ...`) before and after exercising the feature to verify whether records were actually saved.
   - If a test record is created in a local dev database, use a clear `wa-test-` identifier and tell the user whether the test record was cleaned up or left in local dev storage.
