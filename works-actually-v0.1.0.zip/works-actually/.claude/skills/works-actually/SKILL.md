---
name: works-actually
description: Checks whether a website or web app feature actually works from a real user's perspective, gathers runtime and backend evidence, explains issues in plain English, and prepares a fix brief before editing code. Use when the user asks "does my signup/checkout/form/feature actually work", wants to test or verify a user journey, audit an AI-built web app feature, or run /works-actually.
argument-hint: "[feature, user flow, or page to check]"
license: MIT
compatibility: Designed for Claude Code. Follows the Agent Skills (agentskills.io) standard. Uses existing local dev servers, browser tools, or HTTP/DOM/database checks without requiring paid APIs.
metadata:
  author: aiwithjash
  version: "0.1.0"
---

# Works, Actually

Does it actually work? This skill checks whether a real person can use a specific website or web app feature from start to finish, proves what happened with concrete evidence, explains the result in plain English, and prepares a practical fix brief for the coding agent.

## Core Rule: Diagnose First, Then Hand Off

During the checking phase, you are an investigator, not a silent fixer.

1. **Read-Only Audit with Respect to Application Code**: Do not edit, refactor, or patch application source files, configuration files, or dependencies while checking a feature.
2. **Evidence Over Appearances**: A rendered page, a clickable button, a `200 OK` status, or a green success toast does not prove a feature works. Check whether the underlying state actually changed (for example, a database row was created, a session cookie was issued, an item persisted in the cart, or an API payload matched expectations).
3. **Stop and Ask Before Fixing**: End every audit report with the exact handoff choice unless the user already explicitly authorized both checking and fixing in their request:

   > "I found these issues. Would you like me to fix them?"

4. **Authorized Fixes Only**:
   - If the user asks to **check** or **audit** only, stop at the handoff question and wait for confirmation.
   - If the user explicitly asked to **check and fix** upfront (or replies "yes" after reviewing the report), transition clearly into a separate **Fix & Re-verify Phase**, apply the fixes from the brief, re-run the failed user journey, and report the before-and-after evidence.

## When to Use This Skill

Trigger this skill when the user invokes `/works-actually $ARGUMENTS` or asks questions like:

- "Does my signup flow actually work?"
- "Check whether customers can add a product to the cart."
- "Does the contact form really send a message?"
- "Check my image upload feature."
- "Does checkout work up to the point where a payment would be made?"
- "Check whether the booking form saves the appointment."
- "Can a real user log in and reset their password?"

Keep the check focused on **one user-specified feature or journey at a time**. If the user asks to check "the whole app" without naming a flow, pick the primary core journey (or ask them which feature matters most right now) rather than running a slow, generic audit across every file.

## Permission, Privacy, and Safety Boundaries

Follow these boundaries on every run:

- **Target Environment**: Default to `localhost`, local dev servers, or explicitly authorized staging/test URLs. Do not run active form submissions against live production sites unless the user explicitly authorizes a safe read-only check.
- **No Real Purchases or Charges**: Never submit real credit card numbers, trigger live Stripe/PayPal/Razorpay charges, or complete paid orders on live payment gateways. Stop at the payment boundary or use verified sandbox/test mode.
- **No Unsolicited External Messages**: Never send emails, SMS messages, Slack alerts, or webhooks to real people or external customers. Use local mail catchers, console logs, mocked transports, or safe test addresses (such as `test@example.com`) only when external delivery is disabled or sandboxed.
- **No Destructive Data Actions**: Never delete production records, drop tables, wipe user data, or mutate real customer accounts. If local test records are created during a check, use obvious prefix labels (such as `wa-test-...`) and note them in the report.
- **Zero Secret Exposure**: Never print, log, commit, or include API keys, passwords, tokens, or `.env` secret values in the report. Refer to environment variables by name only (for example, `SMTP_HOST is unset in .env.local`).
- **No Security Bypass**: Never weaken authentication, disable CSRF/CORS guards, or alter permissions to make a check pass.
- **No Unapproved Installs**: Do not install new npm/pip packages or alter project config files during the audit. Reuse existing tools first.
- **Scoped Claims**: A passing check means the tested user journey worked under the observed conditions. Never claim the entire application is secure, accessible, compliant, or production-ready based on a feature check.

## 10-Step Verification Workflow

### Step 1: Understand the Feature and Intended Outcome

Identify the target feature from `$ARGUMENTS` or the user's message. Define what "working" means for a real person:

- **User inputs**: What the person types, selects, uploads, or clicks.
- **Visible feedback**: What page, message, redirect, or error state they should see.
- **Real outcome**: What must happen behind the scenes (account created, cart updated, file stored, appointment saved).

See [references/journey-checklists.md](references/journey-checklists.md) for common web feature checklists.

### Step 2: Inspect Project Instructions and Application Code

Read `CLAUDE.md`, `AGENTS.md`, `README.md`, and `package.json` (or `pyproject.toml`, `requirements.txt`, `Makefile`) first. Trace the feature's actual code path:

- Frontend component, form handler, validation rules, and error state rendering.
- API route, server action, or controller handling the request.
- Database query, storage call, or external service integration.

Look for classic AI-generated traps: buttons with no `onClick` or `type="submit"`, form handlers that `console.log` and show a fake success message without calling an API, API routes that swallow errors and return `200 OK`, or missing error UI when an API returns `400`/`500`.

### Step 3: Identify How the App Runs and Available Tools

Check what is already running or installed without installing new dependencies:

1. Check if a local dev server is already listening (for example, ports `3000`, `5173`, `8000`, `8080`).
2. If not running, check how the project starts (`npm run dev`, `python app.py`, etc.) and launch it locally if permitted.
3. Detect available verification tools in priority order (see [references/tool-fallbacks.md](references/tool-fallbacks.md)):
   - **Tier 1 (Real Browser)**: Playwright MCP, Chrome/Chromium browser tool, existing Playwright/Cypress runner, or local headless browser.
   - **Tier 2 (Local HTTP + DOM/State Execution)**: Local HTTP requests (`curl`, `fetch`, Python `urllib`/`requests`) paired with HTML form parsing and direct database/storage state inspection.
   - **Tier 3 (Static Trace + Targeted Unit/Handler Execution)**: When the app cannot start due to missing credentials or services, run isolated handler checks and mark live execution steps as `Blocked / not tested`.

### Step 4: Select the Smallest Useful Check Set

Do not run a massive test suite. Pick **2 to 4 focused checks**:

1. **Happy Path**: Can a real user complete the feature with valid input and get the real backend outcome?
2. **Validation / Error State**: If the user submits empty or invalid input (or the server returns an error), does the UI show a clear, helpful message instead of crashing or silently failing?
3. **Persistence / State Check**: Does the result survive a page reload or appear in the database/storage?
4. **Safety Boundary Check** (if applicable): Does the flow reach the external payment/email/third-party boundary safely without triggering a real-world side effect?

### Step 5: Exercise the Feature Safely

Run the selected checks against the local or authorized environment:

- Fill inputs the way a real user would.
- Observe loading states, button disable behavior, network status codes, console errors, and UI updates.
- Stop immediately if the next action would charge a real payment method, message a real person, or alter production data.

### Step 6: Verify Backend and Persistence Effects

Never trust the UI alone. Confirm the backend effect when accessible:

- **Signup / Auth**: Check that the user record exists in the local database/store, password hashing occurred, and login or session token generation works.
- **Cart / Checkout**: Check that cart items persist across reloads or session state and totals match item prices.
- **Contact / Booking / CRUD Forms**: Check that the submission was written to the database, local queue, or log, and that server validation rejects malformed payloads.
- **File / Image Upload**: Check that the uploaded file exists on disk or local storage bucket, enforces size/type checks, and renders via its returned URL.

### Step 7: Assign Honest Result Labels and Record Evidence

Assign one of four strict labels to the overall feature and to each sub-check:

- **Passed**: Observed runtime and backend behavior directly supports the claim.
- **Failed**: A reproducible bug, silent failure, broken UI state, or server error was observed.
- **Blocked / not tested**: The check could not be completed because a server, database, credential, browser tool, or safe sandbox was unavailable.
- **Needs human review**: The technical check ran, but the final outcome requires human judgment (such as visual polish, copy tone, or verifying an external dashboard the agent cannot access).

**Golden Rule**: Never treat missing evidence as `Passed`. Never fabricate command outputs, HTTP responses, screenshots, or database states.

### Step 8: Present a Plain-English Report

Write the report so a nontechnical founder or vibe coder can understand the verdict in 10 seconds. Avoid unexplained jargon. Translate technical findings into user impact (for example, say "When a customer clicks Sign Up, the page shows a green success message, but no account is actually saved in the database" before showing the technical evidence).

Use the report structure in [references/report-templates.md](references/report-templates.md).

### Step 9: Provide the Agent Fix Brief

Below the plain-English summary, include a structured **Fix Brief** for each issue found:

- **What happened**: Plain-English description of the user-facing failure.
- **Evidence**: Exact observed HTTP status, console/server error, DOM state, or database check result.
- **Likely area**: Specific file paths and line numbers verified during code inspection. Distinguish confirmed causes from suspected causes. Never invent file paths.
- **Suggested fix**: Concrete, minimal change the coding agent should make.
- **How to verify**: The exact user journey and backend check to rerun after the fix.

### Step 10: Ask Before Fixing (or Execute Pre-Authorized Fixes)

- **Default (Audit Request)**: Close with:
  `"I found these issues. Would you like me to fix them?"`
  (Or if only one issue was found: `"Would you like me to fix the [feature] issue and test it again?"`)
  Wait for the user's reply before modifying any application files.
- **If Zero Issues Were Found**: Clearly state what passed, list any `Blocked / not tested` or `Needs human review` items, and ask if they want to check another feature or unblock the remaining items.
- **If Fixes Were Already Explicitly Authorized**: Clearly add a heading `## Phase 2: Applying Authorized Fixes & Re-Testing`, apply the fixes, rerun the exact checks from Step 5 and Step 6, and report the updated status with fresh evidence.
