# Sample Report 1: Signup Form That Looks Functional But Fails Behind the Scenes

User prompt:
> "Does my signup flow actually work?"

---

## Works, Actually Report

**Feature**: Signup Flow (`/signup`)
**Result**: Not working (Failed)
**Environment**: Local dev server (`http://localhost:8000`), SQLite (`dev.db`), Headless Chromium

### Summary in Plain English
The signup page looks finished and even shows a green "Welcome aboard!" banner when a user clicks **Create Account**, but no account is actually created. Behind the scenes, the server crashes with an error and saves nothing to the database.

### Check Breakdown
- **[Passed]** Empty email validation: Submitting the form with a blank email blocks submission and shows `"Please enter your email address."`
- **[Failed]** Valid signup submission: Submitting valid details (`wa-test-user@example.com`) returns `HTTP 500 Internal Server Error` and creates `0` database records, while the UI falsely displays a green success banner.
- **[Blocked / not tested]** Welcome email delivery: `SMTP_HOST` is not configured in the local environment, so external email delivery was not tested.

### What Works
- The signup page renders at `/signup` with name, email, and password inputs.
- Client-side validation rejects an empty email address before sending a network request.

### Problems Found

#### 1. Valid signup returns a 500 error and shows a false success message
- **What happened**: When a user fills in valid signup details and submits the form, the frontend shows `"Welcome aboard! Check your inbox"` without checking if the server request succeeded. Meanwhile, `POST /api/signup` fails with status `500` and no user row is written to the `users` table.
- **Evidence**:
  - Network response: `POST /api/signup` returned `500 Internal Server Error` with body `{"error": "table users has no column named full_name"}`.
  - Database check: `SELECT count(*) FROM users WHERE email = 'wa-test-user@example.com'` returned `0` before and `0` after submission.
  - UI observation: `#signup-status` rendered `"Welcome aboard! Check your inbox"` despite the `500` response.
- **Likely area**:
  - `app.py:88` (confirmed: `INSERT INTO users (full_name, email, password_hash)` references `full_name`, whereas the schema defines column `name`).
  - `templates/signup.html:41` (confirmed: the `fetch('/api/signup')` handler sets the success banner before checking `if (!res.ok)`).
- **Suggested fix**:
  1. In `app.py`, update the `INSERT INTO users` query to use the `name` column matching the `users` table schema.
  2. In `templates/signup.html`, check `if (!response.ok)` after `fetch('/api/signup')` and display the server error message in `#signup-error` instead of showing the success banner.
- **How to verify**:
  1. Submit `/signup` with `name="Test User"`, `email="wa-test-user@example.com"`, and a valid password.
  2. Confirm `POST /api/signup` returns `201 Created` and `SELECT count(*) FROM users WHERE email = 'wa-test-user@example.com'` returns `1`.
  3. Trigger a duplicate signup with the same email and confirm the UI displays an error banner instead of `"Welcome aboard!"`.

### Could Not Check (Blocked / Needs Human Review)
- **Welcome email delivery**: **Blocked / not tested** - No `SMTP_HOST` or local mail catcher is configured in the test environment.

### Next Step
I found these issues. Would you like me to fix them?
