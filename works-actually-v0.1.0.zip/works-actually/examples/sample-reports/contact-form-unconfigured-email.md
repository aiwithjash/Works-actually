# Sample Report 3: Contact Form With Silent Error Handling and Unconfigured Email Service

User prompt:
> "Does the contact form really send a message?"

---

## Works, Actually Report

**Feature**: Contact Form (`/contact`)
**Result**: Partially working
**Environment**: Local dev server (`http://localhost:8000`), SQLite (`dev.db`), Headless Chromium

### Summary in Plain English
When a visitor submits a valid contact message, it is saved to your local database table (`contact_messages`), but no email notification is sent because no email provider is configured yet. In addition, if a visitor submits an invalid form (such as an empty message), the server rejects it with a `400` error, but the webpage shows nothing on screen, leaving the user stuck wondering why the button did nothing.

### Check Breakdown
- **[Passed]** Valid message persistence: Submitting a valid name, email, and message returns `201 Created` and stores the message in the `contact_messages` table.
- **[Failed]** Missing error state on invalid input: Submitting an empty message returns `HTTP 400 Bad Request` (`{"error": "Message body cannot be empty"}`), but the UI never renders the error message to the user.
- **[Blocked / not tested]** External email notification: `SMTP_HOST` is unset, so the app skips outbound email delivery.

### What Works
- Submitting a complete message (`wa-test@example.com`, `"Question about bulk pricing"`) saves the record in `contact_messages` with a timestamp and shows `"Thanks! We received your message."`

### Problems Found

#### 1. Form fails silently when the server returns a validation error
- **What happened**: When a user submits the contact form with an empty message or invalid field, the server responds with `400 Bad Request`, but the page stays completely unchanged with no error banner or field highlight.
- **Evidence**:
  - Network response: `POST /api/contact` returned `400 Bad Request` with JSON `{"error": "Message body cannot be empty"}`.
  - DOM check: `#contact-error` remained empty (`""`) and hidden (`display: none`) after the `400` response.
- **Likely area**:
  - `templates/contact.html:52` (confirmed: the submit script only handles `if (res.ok)` and has no `else` branch to populate `#contact-error`).
- **Suggested fix**:
  - Add an `else` branch in `templates/contact.html` that parses `const data = await res.json()`, sets `#contact-error` text to `data.error || "Could not send your message. Please check all fields."`, and makes `#contact-error` visible.
- **How to verify**:
  - Submit `/contact` with an empty message field and confirm `#contact-error` becomes visible with `"Message body cannot be empty"`.
  - Submit `/contact` with valid fields and confirm the error clears and the message is saved in `contact_messages`.

### Could Not Check (Blocked / Needs Human Review)
- **Outbound email delivery**: **Blocked / not tested** - `SMTP_HOST` is not configured in the local environment. Messages are saved to the local database, but real email forwarding requires configuring an email transport or local mail catcher.

### Next Step
I found these issues. Would you like me to fix them?
